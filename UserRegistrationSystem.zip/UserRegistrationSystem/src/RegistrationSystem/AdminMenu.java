package RegistrationSystem;

import javax.swing.JOptionPane;

public class AdminMenu extends javax.swing.JFrame {

    public AdminMenu() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        main_Panel = new javax.swing.JPanel();
        view_Button = new javax.swing.JButton();
        edit_Button = new javax.swing.JButton();
        logout_Button = new javax.swing.JButton();
        adminMenu_Label = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADMIN MENU");
        setResizable(false);

        main_Panel.setBackground(new java.awt.Color(255, 255, 255));

        view_Button.setBackground(new java.awt.Color(0, 0, 51));
        view_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        view_Button.setForeground(new java.awt.Color(255, 255, 255));
        view_Button.setText("View Profile");
        view_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                view_ButtonActionPerformed(evt);
            }
        });

        edit_Button.setBackground(new java.awt.Color(0, 0, 51));
        edit_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        edit_Button.setForeground(new java.awt.Color(255, 255, 255));
        edit_Button.setText("Profile");
        edit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_ButtonActionPerformed(evt);
            }
        });

        logout_Button.setBackground(new java.awt.Color(0, 0, 51));
        logout_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        logout_Button.setForeground(new java.awt.Color(255, 255, 255));
        logout_Button.setText("Logout");
        logout_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logout_ButtonActionPerformed(evt);
            }
        });

        adminMenu_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        adminMenu_Label.setText("ADMIN MENU");

        javax.swing.GroupLayout main_PanelLayout = new javax.swing.GroupLayout(main_Panel);
        main_Panel.setLayout(main_PanelLayout);
        main_PanelLayout.setHorizontalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_PanelLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(logout_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(edit_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(view_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_PanelLayout.createSequentialGroup()
                .addContainerGap(160, Short.MAX_VALUE)
                .addComponent(adminMenu_Label)
                .addGap(16, 16, 16))
        );
        main_PanelLayout.setVerticalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_PanelLayout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(adminMenu_Label)
                .addGap(52, 52, 52)
                .addComponent(view_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(edit_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(logout_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void view_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_view_ButtonActionPerformed
        AdminView adminViewFrame = new AdminView();
        adminViewFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_view_ButtonActionPerformed

    private void edit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_ButtonActionPerformed
       AdminRegistration adminRegistrationFrame = new AdminRegistration();
       adminRegistrationFrame.setVisible(true);
       dispose();
    }//GEN-LAST:event_edit_ButtonActionPerformed

    private void logout_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logout_ButtonActionPerformed
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout",
                                        "Logout",JOptionPane.YES_NO_OPTION);
        if (choice ==JOptionPane.YES_OPTION )
        {
            JOptionPane.showMessageDialog(this , "Logout Successfully","Logout",JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }
        else
        {
           JOptionPane.showMessageDialog(this,"Logout Cancelled","Cancelled",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_logout_ButtonActionPerformed

    public static void main(String args[]) {

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminMenu().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel adminMenu_Label;
    private javax.swing.JButton edit_Button;
    private javax.swing.JButton logout_Button;
    private javax.swing.JPanel main_Panel;
    private javax.swing.JButton view_Button;
    // End of variables declaration//GEN-END:variables
}
