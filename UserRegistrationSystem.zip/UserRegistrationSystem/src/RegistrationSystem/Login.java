package RegistrationSystem;

import java.awt.Color;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;

public class Login extends javax.swing.JFrame {

    public Login() 
    {
        initComponents();
        try 
        {
            Connection();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    Connection con;
    Statement st;
    PreparedStatement pst;
    
    private static final String dbName = "userregistration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/"+dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
    
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);    
        }
    } 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        main_Panel = new javax.swing.JPanel();
        right_Panel = new javax.swing.JPanel();
        login_Label = new javax.swing.JLabel();
        username_Label = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        password_TextField = new javax.swing.JPasswordField();
        show_Password = new javax.swing.JCheckBox();
        login_Button = new javax.swing.JButton();
        noAccount_Label = new javax.swing.JLabel();
        signup_Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("LOGIN");
        setResizable(false);

        main_Panel.setBackground(new java.awt.Color(255, 255, 255));

        right_Panel.setBackground(new java.awt.Color(0, 0, 51));

        javax.swing.GroupLayout right_PanelLayout = new javax.swing.GroupLayout(right_Panel);
        right_Panel.setLayout(right_PanelLayout);
        right_PanelLayout.setHorizontalGroup(
            right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        right_PanelLayout.setVerticalGroup(
            right_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );

        login_Label.setBackground(new java.awt.Color(0, 0, 51));
        login_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        login_Label.setText("Login");

        username_Label.setBackground(new java.awt.Color(0, 0, 51));
        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        username_Label.setText("Username");

        username_TextField.setForeground(new java.awt.Color(153, 153, 153));
        username_TextField.setText("Enter Username");
        username_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                username_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                username_TextFieldFocusLost(evt);
            }
        });

        password_Label.setBackground(new java.awt.Color(0, 0, 51));
        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        password_Label.setText("Password");

        password_TextField.setForeground(new java.awt.Color(153, 153, 153));
        password_TextField.setText("Enter Password");
        password_TextField.setEchoChar('\u0000');
        password_TextField.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusGained(java.awt.event.FocusEvent evt) {
                password_TextFieldFocusGained(evt);
            }
            public void focusLost(java.awt.event.FocusEvent evt) {
                password_TextFieldFocusLost(evt);
            }
        });

        show_Password.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        show_Password.setText("Show password");
        show_Password.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                show_PasswordMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                show_PasswordMouseReleased(evt);
            }
        });
        show_Password.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                show_PasswordActionPerformed(evt);
            }
        });

        login_Button.setBackground(new java.awt.Color(0, 0, 51));
        login_Button.setFont(new java.awt.Font("Segoe UI", 1, 16)); // NOI18N
        login_Button.setForeground(new java.awt.Color(255, 255, 255));
        login_Button.setText("Login");
        login_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                login_ButtonActionPerformed(evt);
            }
        });

        noAccount_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        noAccount_Label.setForeground(new java.awt.Color(0, 0, 51));
        noAccount_Label.setText("Don't have any account?");

        signup_Button.setBackground(new java.awt.Color(0, 0, 51));
        signup_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        signup_Button.setForeground(new java.awt.Color(255, 255, 255));
        signup_Button.setText("Sign Up");
        signup_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                signup_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout main_PanelLayout = new javax.swing.GroupLayout(main_Panel);
        main_Panel.setLayout(main_PanelLayout);
        main_PanelLayout.setHorizontalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_PanelLayout.createSequentialGroup()
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(main_PanelLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(login_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(main_PanelLayout.createSequentialGroup()
                                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(username_Label)
                                    .addComponent(password_Label))
                                .addGap(18, 18, 18)
                                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(show_Password)
                                    .addComponent(password_TextField)
                                    .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 46, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_PanelLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_PanelLayout.createSequentialGroup()
                                .addComponent(noAccount_Label)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(signup_Button)
                                .addGap(73, 73, 73))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_PanelLayout.createSequentialGroup()
                                .addComponent(login_Label)
                                .addGap(130, 130, 130)))))
                .addComponent(right_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        main_PanelLayout.setVerticalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(right_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(main_PanelLayout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addComponent(login_Label)
                .addGap(70, 70, 70)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(username_Label)
                    .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(password_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(password_Label))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(show_Password)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(login_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 112, Short.MAX_VALUE)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(noAccount_Label)
                    .addComponent(signup_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(63, 63, 63))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        getAccessibleContext().setAccessibleDescription("");

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void login_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_login_ButtonActionPerformed
        String acc_username = username_TextField.getText();
        String acc_password = password_TextField.getText();
    
        if (username_TextField.getText().equals("Pelko_29")&& password_TextField.getText().equals("101012"))
        {
            JOptionPane.showMessageDialog(null, "Welcome Admin","Login",JOptionPane.INFORMATION_MESSAGE);
            AdminMenu adminMenuFrame = new AdminMenu();
            adminMenuFrame.setVisible(true);
            dispose();
        }
        else if (username_TextField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Fill out Username","Error",JOptionPane.ERROR_MESSAGE);
            username_TextField.setText("");
            password_TextField.setText("");
        }
        else if (password_TextField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Fill out Password","Error",JOptionPane.ERROR_MESSAGE);
            username_TextField.setText("");
            password_TextField.setText("");
        }
        else if (username_TextField.getText().equals("")||password_TextField.getText().equals(""))
        {
            JOptionPane.showMessageDialog(null, "Fill out Username Field or Password Field","Error",JOptionPane.ERROR_MESSAGE);
            username_TextField.setText("");
            password_TextField.setText("");
        }
        else
        {
        String queryLogin = "SELECT * FROM userinfo WHERE Username = '"+acc_username+"' AND Password = '"+acc_password+"'";
        try 
        {
            pst = con.prepareStatement(queryLogin);
            ResultSet rs = pst.executeQuery();
            
            if (!rs.next())
            {
                JOptionPane.showMessageDialog(null, "Invalid Credentials.","Error",JOptionPane.ERROR_MESSAGE);
                username_TextField.setText("");
                password_TextField.setText("");
            }
            else
            {
                JOptionPane.showMessageDialog(null,  "Welcome User","Login",JOptionPane.INFORMATION_MESSAGE);
                UserProfile userProfileFrame = new UserProfile();
                UserUpdate userUpdateFrame = new UserUpdate();
                                
                String Name = rs.getString("Name");
                String Username = rs.getString("Username");
                String Password = rs.getString("Password");
                String Email = rs.getString("Email");
                String Phone = rs.getString("Phone");
               
                userProfileFrame.name_TextField.setText(Name);
                userProfileFrame.username_TextField.setText(Username);
                userProfileFrame.password_TextField.setText(Password);
                userProfileFrame.email_TextField.setText(Email);
                userProfileFrame.contact_TextField.setText(Phone);
                          
                userUpdateFrame.eName_TextField.setText(Name);
                userUpdateFrame.eUsername_TextField.setText(Username);
                userUpdateFrame.ePassword_TextField.setText(Password);
                userUpdateFrame.eEmail_TextField.setText(Email);
                userUpdateFrame.eContact_TextField.setText(Phone);
                
                
                userProfileFrame.setVisible(true);
                dispose();
                
            }
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }  
        }  
    }//GEN-LAST:event_login_ButtonActionPerformed

    private void username_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_username_TextFieldFocusGained
        if (username_TextField.getText().equals("Enter Username"))
        {
            username_TextField.setText("");
            username_TextField.setForeground(Color.BLACK);
        }
    }//GEN-LAST:event_username_TextFieldFocusGained

    private void username_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_username_TextFieldFocusLost
        if (username_TextField.getText().equals(""))
        {
            username_TextField.setText("Enter Username");
            username_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_username_TextFieldFocusLost

    private void password_TextFieldFocusGained(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_password_TextFieldFocusGained
        if (String.valueOf(password_TextField.getPassword()).equals("Enter Password"))
        {
           password_TextField.setText("");
           password_TextField.setForeground(Color.BLACK);
           password_TextField.setEchoChar('•');
        }
    }//GEN-LAST:event_password_TextFieldFocusGained

    private void password_TextFieldFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_password_TextFieldFocusLost
       if (password_TextField.getPassword().length<1)
        {
            password_TextField.setEchoChar('\u0000');
            password_TextField.setText("Enter Password");
            password_TextField.setForeground(new java.awt.Color(153,153,153));
        }
    }//GEN-LAST:event_password_TextFieldFocusLost

    private void show_PasswordMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_show_PasswordMousePressed
        show_Password.setForeground(Color.gray);
    }//GEN-LAST:event_show_PasswordMousePressed

    private void show_PasswordMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_show_PasswordMouseReleased
        show_Password.setForeground(Color.BLACK);
    }//GEN-LAST:event_show_PasswordMouseReleased

    private void show_PasswordActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_show_PasswordActionPerformed
        if (show_Password.isSelected())
        {
            password_TextField.setEchoChar((char)0);
        }
        else 
        {
            password_TextField.setEchoChar('•');
        } 
    }//GEN-LAST:event_show_PasswordActionPerformed

    private void signup_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_signup_ButtonActionPerformed
        Registration frameRegistration = new Registration();
        frameRegistration.setVisible(true);
        dispose();
    }//GEN-LAST:event_signup_ButtonActionPerformed
    
    
    
    
    
    
    
    
    
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Login().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton login_Button;
    private javax.swing.JLabel login_Label;
    private javax.swing.JPanel main_Panel;
    private javax.swing.JLabel noAccount_Label;
    private javax.swing.JLabel password_Label;
    private javax.swing.JPasswordField password_TextField;
    private javax.swing.JPanel right_Panel;
    private javax.swing.JCheckBox show_Password;
    private javax.swing.JButton signup_Button;
    private javax.swing.JLabel username_Label;
    private javax.swing.JTextField username_TextField;
    // End of variables declaration//GEN-END:variables
}
