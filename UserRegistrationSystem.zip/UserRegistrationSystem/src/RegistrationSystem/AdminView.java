package RegistrationSystem;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class AdminView extends javax.swing.JFrame {

 
    public AdminView() 
    {
        initComponents();
        view_Table.setEnabled(false);
        try 
        {
            tableUpdate();
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(AdminRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    Connection con;
    Statement st;
    PreparedStatement insert;
    
    private static final String dbName = "userregistration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/"+dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        main_Panel = new javax.swing.JPanel();
        scrollPane = new javax.swing.JScrollPane();
        view_Table = new javax.swing.JTable();
        back_Button = new javax.swing.JButton();
        Logout_Button = new javax.swing.JButton();
        viewUser_Label = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADMIN VIEW");
        setResizable(false);

        main_Panel.setBackground(new java.awt.Color(0, 0, 51));

        view_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Name", "Username", "Password", "Email", "Contact No."
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        view_Table.getTableHeader().setReorderingAllowed(false);
        scrollPane.setViewportView(view_Table);

        back_Button.setBackground(new java.awt.Color(0, 0, 51));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        back_Button.setForeground(new java.awt.Color(255, 255, 255));
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        Logout_Button.setBackground(new java.awt.Color(0, 0, 51));
        Logout_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Logout_Button.setForeground(new java.awt.Color(255, 255, 255));
        Logout_Button.setText("Logout");
        Logout_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                Logout_ButtonActionPerformed(evt);
            }
        });

        viewUser_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        viewUser_Label.setForeground(new java.awt.Color(255, 255, 255));
        viewUser_Label.setText("View User Profile");

        javax.swing.GroupLayout main_PanelLayout = new javax.swing.GroupLayout(main_Panel);
        main_Panel.setLayout(main_PanelLayout);
        main_PanelLayout.setHorizontalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_PanelLayout.createSequentialGroup()
                .addGap(31, 31, 31)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(main_PanelLayout.createSequentialGroup()
                        .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(viewUser_Label)
                        .addGap(36, 36, 36))
                    .addGroup(main_PanelLayout.createSequentialGroup()
                        .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(scrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 844, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(Logout_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(27, Short.MAX_VALUE))))
        );
        main_PanelLayout.setVerticalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_PanelLayout.createSequentialGroup()
                .addContainerGap(12, Short.MAX_VALUE)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(viewUser_Label)
                    .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(scrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(Logout_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 1, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        AdminMenu adminMenuFrame = new AdminMenu();
        adminMenuFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void Logout_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_Logout_ButtonActionPerformed
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout",
                                        "Logout",JOptionPane.YES_NO_OPTION);
        if (choice ==JOptionPane.YES_OPTION )
        {
            JOptionPane.showMessageDialog(this , "Logout Successfully","Logout",JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }
        else
        {
           JOptionPane.showMessageDialog(this,"Logout Cancelled","Cancelled",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_Logout_ButtonActionPerformed
 private void tableUpdate() throws SQLException{
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("Select * from userinfo");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c =Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)view_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                for (int a = 1 ;a<=c; a++)
                {
                    vec.add(rs.getString("Name"));
                    vec.add(rs.getString("Username"));
                    vec.add(rs.getString("Password"));
                    vec.add(rs.getString("Email"));
                    vec.add(rs.getString("Phone"));
                }
                dtm.addRow(vec);
            }
            
          
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (SQLException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminView().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Logout_Button;
    private javax.swing.JButton back_Button;
    private javax.swing.JPanel main_Panel;
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JLabel viewUser_Label;
    public static javax.swing.JTable view_Table;
    // End of variables declaration//GEN-END:variables
}
