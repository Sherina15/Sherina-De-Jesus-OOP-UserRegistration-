package RegistrationSystem;


import static RegistrationSystem.UserUpdate.eContact_TextField;
import static RegistrationSystem.UserUpdate.eEmail_TextField;
import static RegistrationSystem.UserUpdate.eName_TextField;
import static RegistrationSystem.UserUpdate.ePassword_TextField;
import static RegistrationSystem.UserUpdate.eUsername_TextField;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.swing.JOptionPane;

public class UserProfile extends javax.swing.JFrame {

    public UserProfile() 
    {
        initComponents();
        
        name_TextField.setEditable(false);
        username_TextField.setEditable(false);
        password_TextField.setEditable(false);
        email_TextField.setEditable(false);
        contact_TextField.setEditable(false);
        
        try 
        {
            Connection();
        } catch (SQLException ex) 
        {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    Connection con;
    Statement st;
    PreparedStatement pst;
    
    private static final String dbName = "userregistration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/"+dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
    
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        main_Panel = new javax.swing.JPanel();
        inner_Panel = new javax.swing.JPanel();
        profile_Label = new javax.swing.JLabel();
        name_Label = new javax.swing.JLabel();
        name_TextField = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        username_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        password_TextField = new javax.swing.JTextField();
        email_Label = new javax.swing.JLabel();
        email_TextField = new javax.swing.JTextField();
        phone_Label = new javax.swing.JLabel();
        contact_TextField = new javax.swing.JTextField();
        edit_Button = new javax.swing.JButton();
        logout_Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("USER PROFILE");
        setResizable(false);

        main_Panel.setBackground(new java.awt.Color(0, 0, 51));
        main_Panel.setPreferredSize(new java.awt.Dimension(400, 500));

        inner_Panel.setBackground(new java.awt.Color(153, 153, 153));

        profile_Label.setFont(new java.awt.Font("Segoe UI", 1, 48)); // NOI18N
        profile_Label.setForeground(new java.awt.Color(255, 255, 255));
        profile_Label.setText("PROFILE");

        name_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        name_Label.setText("Name");

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_Label.setText("Username");

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Label.setText("Password");

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        email_Label.setText("Email");

        phone_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phone_Label.setText("Contact No.");

        edit_Button.setBackground(new java.awt.Color(0, 0, 51));
        edit_Button.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        edit_Button.setForeground(new java.awt.Color(255, 255, 255));
        edit_Button.setText("Edit");
        edit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_ButtonActionPerformed(evt);
            }
        });

        logout_Button.setBackground(new java.awt.Color(0, 0, 51));
        logout_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        logout_Button.setForeground(new java.awt.Color(255, 255, 255));
        logout_Button.setText("Logout");
        logout_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logout_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout inner_PanelLayout = new javax.swing.GroupLayout(inner_Panel);
        inner_Panel.setLayout(inner_PanelLayout);
        inner_PanelLayout.setHorizontalGroup(
            inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inner_PanelLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(inner_PanelLayout.createSequentialGroup()
                        .addGroup(inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(email_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phone_Label)
                            .addComponent(password_Label)
                            .addComponent(username_Label)
                            .addComponent(name_Label))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(email_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(name_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(password_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(contact_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(inner_PanelLayout.createSequentialGroup()
                        .addComponent(logout_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 99, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 446, Short.MAX_VALUE)
                        .addComponent(edit_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(23, 23, 23))
            .addGroup(inner_PanelLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(profile_Label)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        inner_PanelLayout.setVerticalGroup(
            inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(inner_PanelLayout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addComponent(profile_Label)
                .addGroup(inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(inner_PanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(name_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name_Label))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(username_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(username_Label))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(password_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(password_Label))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(email_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(email_Label))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(inner_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(contact_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(phone_Label))
                        .addGap(12, 12, 12)
                        .addComponent(edit_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(34, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, inner_PanelLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(logout_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())))
        );

        javax.swing.GroupLayout main_PanelLayout = new javax.swing.GroupLayout(main_Panel);
        main_Panel.setLayout(main_PanelLayout);
        main_PanelLayout.setHorizontalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_PanelLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addComponent(inner_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        main_PanelLayout.setVerticalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_PanelLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(inner_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 727, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void edit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_ButtonActionPerformed
        UserUpdate userUpdateFrame = new UserUpdate();
        
        String Name = name_TextField.getText();
        String Username = username_TextField.getText();
        String Password = password_TextField.getText();
        String Email = email_TextField.getText();
        String Contact = contact_TextField.getText();
        
        eName_TextField.setText(Name);
        eUsername_TextField.setText(Username);
        ePassword_TextField.setText(Password);
        eEmail_TextField.setText(Email);
        eContact_TextField.setText(Contact); 
        
        userUpdateFrame.setVisible(true);
        dispose();    
    }//GEN-LAST:event_edit_ButtonActionPerformed

    private void logout_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logout_ButtonActionPerformed
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout",
                                        "Logout",JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION )
        {
           Login loginFrame = new Login();
           loginFrame.setVisible(true);
           dispose();
        }
        else
        {
           JOptionPane.showMessageDialog(this,"Logout Cancelled","Cancelled",JOptionPane.INFORMATION_MESSAGE);
        }
    }//GEN-LAST:event_logout_ButtonActionPerformed

    public static void main(String args[]) {
    
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserProfile().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public static javax.swing.JTextField contact_TextField;
    private javax.swing.JButton edit_Button;
    private javax.swing.JLabel email_Label;
    public static javax.swing.JTextField email_TextField;
    private javax.swing.JPanel inner_Panel;
    private javax.swing.JButton logout_Button;
    private javax.swing.JPanel main_Panel;
    private javax.swing.JLabel name_Label;
    public static javax.swing.JTextField name_TextField;
    private javax.swing.JLabel password_Label;
    public static javax.swing.JTextField password_TextField;
    private javax.swing.JLabel phone_Label;
    private javax.swing.JLabel profile_Label;
    private javax.swing.JLabel username_Label;
    public static javax.swing.JTextField username_TextField;
    // End of variables declaration//GEN-END:variables
}
