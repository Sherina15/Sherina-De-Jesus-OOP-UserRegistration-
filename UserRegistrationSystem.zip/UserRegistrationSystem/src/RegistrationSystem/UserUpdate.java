package RegistrationSystem;

import static RegistrationSystem.UserProfile.contact_TextField;
import static RegistrationSystem.UserProfile.email_TextField;
import static RegistrationSystem.UserProfile.name_TextField;
import static RegistrationSystem.UserProfile.password_TextField;
import static RegistrationSystem.UserProfile.username_TextField;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.sql.Connection;


public class UserUpdate extends javax.swing.JFrame {


    public UserUpdate() 
    {
        initComponents();
        eName_TextField.setEditable(false);
      
        try 
        {
            Connection();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    Connection con;
    Statement st;
    PreparedStatement pst;
    
    private static final String dbName = "userregistration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/"+dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
    
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);    
        }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        main_Panel = new javax.swing.JPanel();
        editProfile_Label = new javax.swing.JLabel();
        eName_TextField = new javax.swing.JTextField();
        eUsername_TextField = new javax.swing.JTextField();
        ePassword_TextField = new javax.swing.JTextField();
        eContact_TextField = new javax.swing.JTextField();
        eEmail_TextField = new javax.swing.JTextField();
        name_Label = new javax.swing.JLabel();
        username_Label = new javax.swing.JLabel();
        password_Label = new javax.swing.JLabel();
        emial_Label = new javax.swing.JLabel();
        phone_Label = new javax.swing.JLabel();
        update_Button = new javax.swing.JButton();
        cancel_Button = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("USER UPDATE");
        setResizable(false);

        main_Panel.setBackground(new java.awt.Color(0, 0, 51));

        editProfile_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        editProfile_Label.setForeground(new java.awt.Color(255, 255, 255));
        editProfile_Label.setText("EDIT PROFILE");

        eName_TextField.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                eName_TextFieldMouseClicked(evt);
            }
        });

        eContact_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                eContact_TextFieldKeyTyped(evt);
            }
        });

        name_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        name_Label.setForeground(new java.awt.Color(255, 255, 255));
        name_Label.setText("Name");

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_Label.setForeground(new java.awt.Color(255, 255, 255));
        username_Label.setText("Username");

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Label.setForeground(new java.awt.Color(255, 255, 255));
        password_Label.setText("Password");

        emial_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        emial_Label.setForeground(new java.awt.Color(255, 255, 255));
        emial_Label.setText("Email");

        phone_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phone_Label.setForeground(new java.awt.Color(255, 255, 255));
        phone_Label.setText("Contact No.");

        update_Button.setBackground(new java.awt.Color(0, 0, 51));
        update_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        update_Button.setForeground(new java.awt.Color(255, 255, 255));
        update_Button.setText("Update");
        update_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                update_ButtonActionPerformed(evt);
            }
        });

        cancel_Button.setBackground(new java.awt.Color(0, 0, 51));
        cancel_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        cancel_Button.setForeground(new java.awt.Color(255, 255, 255));
        cancel_Button.setText("Cancel");
        cancel_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cancel_ButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout main_PanelLayout = new javax.swing.GroupLayout(main_Panel);
        main_Panel.setLayout(main_PanelLayout);
        main_PanelLayout.setHorizontalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_PanelLayout.createSequentialGroup()
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(main_PanelLayout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(emial_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(eEmail_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(main_PanelLayout.createSequentialGroup()
                        .addGap(29, 29, 29)
                        .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(main_PanelLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(password_Label)
                                .addGap(18, 18, 18)
                                .addComponent(ePassword_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(main_PanelLayout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(name_Label)
                                    .addComponent(username_Label))
                                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, main_PanelLayout.createSequentialGroup()
                                        .addGap(0, 6, Short.MAX_VALUE)
                                        .addComponent(eUsername_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(main_PanelLayout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(eName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))))
                    .addGroup(main_PanelLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(phone_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, main_PanelLayout.createSequentialGroup()
                                .addComponent(cancel_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(update_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(eContact_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(86, 86, 86))
            .addGroup(main_PanelLayout.createSequentialGroup()
                .addGap(136, 136, 136)
                .addComponent(editProfile_Label)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        main_PanelLayout.setVerticalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_PanelLayout.createSequentialGroup()
                .addGap(40, 40, 40)
                .addComponent(editProfile_Label)
                .addGap(60, 60, 60)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(eName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(name_Label))
                .addGap(18, 18, 18)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(eUsername_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(username_Label))
                .addGap(18, 18, 18)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ePassword_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(password_Label))
                .addGap(18, 18, 18)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(eEmail_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(emial_Label))
                .addGap(18, 18, 18)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(eContact_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(phone_Label))
                .addGap(18, 18, 18)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cancel_Button, javax.swing.GroupLayout.DEFAULT_SIZE, 40, Short.MAX_VALUE)
                    .addComponent(update_Button, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(22, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_Panel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void cancel_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cancel_ButtonActionPerformed
        UserProfile userProfileFrame = new UserProfile();
        
        String Name = eName_TextField.getText();
        String Username = eUsername_TextField.getText();
        String Password = ePassword_TextField.getText();
        String Email = eEmail_TextField.getText();
        String Contact = eContact_TextField.getText();
 
        name_TextField.setText(Name);
        username_TextField.setText(Username);
        password_TextField.setText(Password);
        email_TextField.setText(Email);
        contact_TextField.setText(Contact);
        
        userProfileFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_cancel_ButtonActionPerformed

    private void update_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_update_ButtonActionPerformed
  
        String Name = eName_TextField.getText();
        String Username = eUsername_TextField.getText();
        String Password = ePassword_TextField.getText();
        String Email = eEmail_TextField.getText();
        String Contact = eContact_TextField.getText();
  
            try 
            {
                
            int Update = JOptionPane.showConfirmDialog(null, "Confirm to Update", "Warning", JOptionPane.YES_NO_OPTION);
            
            if (Update == JOptionPane.YES_OPTION) 
            { 
                
                
                String updateQuery = "UPDATE userinfo SET Username=?, Password=?, Email=?, Phone=? WHERE Name=?";
                pst = con.prepareStatement(updateQuery);
                pst.setString(1, Username);
                pst.setString(2, Password);
                pst.setString(3, Email);
                pst.setString(4, Contact);
                pst.setString(5, Name);
 
                int rowsAffected = pst.executeUpdate();
                
                if (rowsAffected > 0) 
                {
                    JOptionPane.showMessageDialog(null, "Profile updated successfully.","Update",JOptionPane.INFORMATION_MESSAGE); 
                    UserProfile userProfileFrame = new UserProfile();
                    name_TextField.setText(Name);
                    username_TextField.setText(Username);
                    password_TextField.setText(Password);
                    email_TextField.setText(Email);
                    contact_TextField.setText(Contact);
                    userProfileFrame.setVisible(true);
                    dispose();   
                } 
                else
                {
                   
                }
            }
          
            } 
            catch (SQLException ex) 
            {
                Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, "Error updating profile", ex);
                JOptionPane.showMessageDialog(null, "An error occurred while updating the profile. Please try again later.");
            }
    }//GEN-LAST:event_update_ButtonActionPerformed

    private void eName_TextFieldMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_eName_TextFieldMouseClicked
        JOptionPane.showMessageDialog(null, "Name cannot be edit.","Warning",JOptionPane.WARNING_MESSAGE);
    }//GEN-LAST:event_eName_TextFieldMouseClicked

    private void eContact_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_eContact_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            eContact_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "Input numbers only.", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            eContact_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_eContact_TextFieldKeyTyped


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UserUpdate().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancel_Button;
    public static javax.swing.JTextField eContact_TextField;
    public static javax.swing.JTextField eEmail_TextField;
    public static javax.swing.JTextField eName_TextField;
    public static javax.swing.JTextField ePassword_TextField;
    public static javax.swing.JTextField eUsername_TextField;
    private javax.swing.JLabel editProfile_Label;
    private javax.swing.JLabel emial_Label;
    private javax.swing.JPanel main_Panel;
    private javax.swing.JLabel name_Label;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phone_Label;
    private javax.swing.JButton update_Button;
    private javax.swing.JLabel username_Label;
    // End of variables declaration//GEN-END:variables
}
