package RegistrationSystem;

import java.sql.ResultSetMetaData;
import java.sql.ResultSet;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.sql.PreparedStatement;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;

public class AdminRegistration extends javax.swing.JFrame {


    public AdminRegistration() 
    {
        initComponents();
        
        
        try 
        {
            Connection();
            tableUpdate();
        } 
        catch (SQLException ex) 
        {
            Logger.getLogger(AdminRegistration.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    Connection con;
    Statement st;
    PreparedStatement insert;
    PreparedStatement pst;
    
    private static final String dbName = "userregistration" ;
    private static final String dbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String dbUrl = "jdbc:mysql://localhost:3306/"+dbName;
    private static final String dbUsername = "root";
    private static final String dbPassword = "";
    
    public void Connection()throws SQLException
    {
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            st = con.createStatement();
            
            if (con != null)
            {
                System.out.println("Connection successful");
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
            
        }
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        main_Panel = new javax.swing.JPanel();
        adminRegistration_Label = new javax.swing.JLabel();
        scrollPane = new javax.swing.JScrollPane();
        adminRegistration_Table = new javax.swing.JTable();
        back_Button = new javax.swing.JButton();
        logout_Button = new javax.swing.JButton();
        add_Button = new javax.swing.JButton();
        clear_Button = new javax.swing.JButton();
        edit_Button = new javax.swing.JButton();
        delete_Button = new javax.swing.JButton();
        ePassword_TextField = new javax.swing.JPasswordField();
        name_Label = new javax.swing.JLabel();
        eName_TextField = new javax.swing.JTextField();
        username_Label = new javax.swing.JLabel();
        eUsername_TextField = new javax.swing.JTextField();
        password_Label = new javax.swing.JLabel();
        showPassword = new javax.swing.JCheckBox();
        email_Label = new javax.swing.JLabel();
        eEmail_TextField = new javax.swing.JTextField();
        phone_Label = new javax.swing.JLabel();
        eContact_TextField = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("ADMIN REGISTRATION");
        setResizable(false);

        main_Panel.setBackground(new java.awt.Color(0, 0, 51));

        adminRegistration_Label.setFont(new java.awt.Font("Segoe UI", 1, 36)); // NOI18N
        adminRegistration_Label.setForeground(new java.awt.Color(255, 255, 255));
        adminRegistration_Label.setText("Admin Registration");

        adminRegistration_Table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Name", "Username", "Password", "Email", "Contact No."
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        adminRegistration_Table.getTableHeader().setReorderingAllowed(false);
        adminRegistration_Table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                adminRegistration_TableMouseClicked(evt);
            }
        });
        scrollPane.setViewportView(adminRegistration_Table);
        if (adminRegistration_Table.getColumnModel().getColumnCount() > 0) {
            adminRegistration_Table.getColumnModel().getColumn(0).setResizable(false);
            adminRegistration_Table.getColumnModel().getColumn(1).setResizable(false);
            adminRegistration_Table.getColumnModel().getColumn(2).setResizable(false);
            adminRegistration_Table.getColumnModel().getColumn(3).setResizable(false);
            adminRegistration_Table.getColumnModel().getColumn(4).setResizable(false);
        }

        back_Button.setBackground(new java.awt.Color(0, 0, 51));
        back_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        back_Button.setForeground(new java.awt.Color(255, 255, 255));
        back_Button.setText("Back");
        back_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                back_ButtonActionPerformed(evt);
            }
        });

        logout_Button.setBackground(new java.awt.Color(0, 0, 51));
        logout_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        logout_Button.setForeground(new java.awt.Color(255, 255, 255));
        logout_Button.setText("Logout");
        logout_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                logout_ButtonActionPerformed(evt);
            }
        });

        add_Button.setBackground(new java.awt.Color(0, 0, 51));
        add_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        add_Button.setForeground(new java.awt.Color(255, 255, 255));
        add_Button.setText("Add User");
        add_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                add_ButtonActionPerformed(evt);
            }
        });

        clear_Button.setBackground(new java.awt.Color(0, 0, 51));
        clear_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        clear_Button.setForeground(new java.awt.Color(255, 255, 255));
        clear_Button.setText("Clear All");
        clear_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clear_ButtonActionPerformed(evt);
            }
        });

        edit_Button.setBackground(new java.awt.Color(0, 0, 51));
        edit_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        edit_Button.setForeground(new java.awt.Color(255, 255, 255));
        edit_Button.setText("Edit");
        edit_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                edit_ButtonActionPerformed(evt);
            }
        });

        delete_Button.setBackground(new java.awt.Color(0, 0, 51));
        delete_Button.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        delete_Button.setForeground(new java.awt.Color(255, 255, 255));
        delete_Button.setText("Delete");
        delete_Button.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                delete_ButtonActionPerformed(evt);
            }
        });

        name_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        name_Label.setForeground(new java.awt.Color(255, 255, 255));
        name_Label.setText("Name");

        eName_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eName_TextFieldActionPerformed(evt);
            }
        });

        username_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        username_Label.setForeground(new java.awt.Color(255, 255, 255));
        username_Label.setText("Username");

        password_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        password_Label.setForeground(new java.awt.Color(255, 255, 255));
        password_Label.setText("Password");

        showPassword.setBackground(new java.awt.Color(0, 0, 51));
        showPassword.setForeground(new java.awt.Color(255, 255, 255));
        showPassword.setText("Show password");
        showPassword.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                showPasswordMouseClicked(evt);
            }
        });

        email_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        email_Label.setForeground(new java.awt.Color(255, 255, 255));
        email_Label.setText("Email");

        eEmail_TextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eEmail_TextFieldActionPerformed(evt);
            }
        });

        phone_Label.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        phone_Label.setForeground(new java.awt.Color(255, 255, 255));
        phone_Label.setText("Contact No.");

        eContact_TextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                eContact_TextFieldKeyTyped(evt);
            }
        });

        javax.swing.GroupLayout main_PanelLayout = new javax.swing.GroupLayout(main_Panel);
        main_Panel.setLayout(main_PanelLayout);
        main_PanelLayout.setHorizontalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_PanelLayout.createSequentialGroup()
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(eEmail_TextField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(eContact_TextField, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(add_Button, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(main_PanelLayout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(username_Label)
                            .addComponent(phone_Label)
                            .addComponent(eUsername_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(name_Label)
                            .addComponent(eName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(password_Label)
                            .addComponent(ePassword_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(email_Label, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(clear_Button)
                            .addComponent(showPassword))))
                .addGap(18, 18, 18)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(main_PanelLayout.createSequentialGroup()
                        .addComponent(edit_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(delete_Button)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(logout_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(scrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 745, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_PanelLayout.createSequentialGroup()
                            .addComponent(adminRegistration_Label)
                            .addGap(13, 13, 13))))
                .addContainerGap(18, Short.MAX_VALUE))
        );
        main_PanelLayout.setVerticalGroup(
            main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(main_PanelLayout.createSequentialGroup()
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(main_PanelLayout.createSequentialGroup()
                        .addContainerGap(10, Short.MAX_VALUE)
                        .addComponent(adminRegistration_Label)
                        .addGap(56, 56, 56)
                        .addComponent(scrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(main_PanelLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addComponent(back_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(68, 68, 68)
                        .addComponent(name_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(eName_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(username_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(eUsername_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(password_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(ePassword_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(showPassword)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(email_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(eEmail_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(phone_Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(eContact_TextField, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(clear_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(5, 5, 5)
                        .addComponent(add_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, main_PanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(edit_Button)
                        .addComponent(delete_Button))
                    .addComponent(logout_Button, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(0, 6, Short.MAX_VALUE)
                .addComponent(main_Panel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents
  
        static int selectedRowIndex;
        
    private void tableUpdate() throws SQLException{
        int c;
        
        try
        {
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("Select * from userinfo");
            ResultSet rs = insert.executeQuery();
            ResultSetMetaData Rss = rs.getMetaData();
            c =Rss.getColumnCount();
            
            DefaultTableModel dtm = (DefaultTableModel)adminRegistration_Table.getModel();
            dtm.setRowCount(0);
            
            while(rs.next())
            {
                Vector vec = new Vector();
                
                for (int a = 1 ;a<=c; a++)
                {
                    vec.add(rs.getString("Name"));
                    vec.add(rs.getString("Username"));
                    vec.add(rs.getString("Password"));
                    vec.add(rs.getString("Email"));
                    vec.add(rs.getString("Phone"));
                }
                
                dtm.addRow(vec);
            }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (SQLException ex) 
        {
               Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    private void add_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_add_ButtonActionPerformed
        eName_TextField.setEditable(true);
        
        String Name = eName_TextField.getText();
        String Username = eUsername_TextField.getText();
        String Password = ePassword_TextField.getText();
        String Email = eEmail_TextField.getText();
        String Contact = eContact_TextField.getText();

            try 
            {
                
                int Update = JOptionPane.showConfirmDialog(null, "Are you sure you want to add"  , "Add", JOptionPane.YES_NO_OPTION);
            
                if (Update == JOptionPane.YES_OPTION) 
                { 
                    if (eName_TextField.getText().equals("")&& eUsername_TextField.getText().equals("")&& ePassword_TextField.getText().equals("")&&eEmail_TextField.getText().equals("")&&eContact_TextField.getText().equals(""))
                    {
                      
                        JOptionPane.showMessageDialog(null, "Empty Fields","Unsuccessful",JOptionPane.ERROR_MESSAGE); 

                    }
                    else
                    {
                    String queryRegister = "INSERT INTO userinfo(Name,Username,Password,Email,Phone) VALUES('"+Name+"', '"+Username+"', '"+Password+"','"+Email+"','"+Contact+"')";
                    pst = con.prepareStatement(queryRegister);

                    int rowsAffected = pst.executeUpdate();
                    tableUpdate();
                    
                    
                
                if (rowsAffected > 0) 
                {
                    JOptionPane.showMessageDialog(null, "Profile added successfully","Added",JOptionPane.INFORMATION_MESSAGE); 
                    UserProfile userProfileFrame = new UserProfile();
                    eName_TextField.setText(Name);
                    eUsername_TextField.setText(Username);
                    ePassword_TextField.setText(Password);
                    eEmail_TextField.setText(Email);
                    eContact_TextField.setText(Contact);
                    
                    eName_TextField.setText("");
                    eUsername_TextField.setText("");
                    ePassword_TextField.setText("");
                    eEmail_TextField.setText("");
                    eContact_TextField.setText("");
   
                } 
                    
                else 
                {
                    JOptionPane.showMessageDialog(null, "Failed to Add profile.");
                    eName_TextField.setText("");
                    eUsername_TextField.setText("");
                    ePassword_TextField.setText("");
                    eEmail_TextField.setText("");
                    eContact_TextField.setText("");
                }
              }
                }
            }
            catch (SQLException ex) 
            {
                Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, "Error updating profile", ex);
                JOptionPane.showMessageDialog(null, "An error occurred while updating the profile. Please try again later.","Error",JOptionPane.ERROR_MESSAGE);
            }   
               
        
    }//GEN-LAST:event_add_ButtonActionPerformed

    private void back_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_back_ButtonActionPerformed
        AdminMenu adminMenuFrame = new AdminMenu();
        adminMenuFrame.setVisible(true);
        dispose();
    }//GEN-LAST:event_back_ButtonActionPerformed

    private void adminRegistration_TableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_adminRegistration_TableMouseClicked
        DefaultTableModel dtm = (DefaultTableModel)adminRegistration_Table.getModel();
        int selectedIndex = adminRegistration_Table.getSelectedRow();
       
        
        selectedRowIndex = adminRegistration_Table.getSelectedRow();
        eName_TextField.setEditable(false);
        
        eName_TextField.setText(dtm.getValueAt(selectedIndex, 0).toString());
        eUsername_TextField.setText(dtm.getValueAt(selectedIndex, 1).toString());
        ePassword_TextField.setText(dtm.getValueAt(selectedIndex, 2).toString());
        eEmail_TextField.setText(dtm.getValueAt(selectedIndex, 3).toString());
        eContact_TextField.setText(dtm.getValueAt(selectedIndex, 4).toString());
        
       
          
    }//GEN-LAST:event_adminRegistration_TableMouseClicked

    private void edit_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_edit_ButtonActionPerformed
        
        
        DefaultTableModel dtm = (DefaultTableModel)adminRegistration_Table.getModel();
        int selectedIndex = adminRegistration_Table.getSelectedRow();
        
        try
        {
            int choice = JOptionPane.showConfirmDialog(this,"Do you sure want to update ", 
                "Update",JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION )
        {
            
            String Name = eName_TextField.getText();
            String Username = eUsername_TextField.getText();
            String Password = ePassword_TextField.getText();
            String Email = eEmail_TextField.getText();
            String Contact = eContact_TextField.getText();
            
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);
            insert = con.prepareStatement("UPDATE userinfo SET Username=?, Password=?, Email=?, Phone=? WHERE Name=?");
            
            insert.setString(1, Username);
            insert.setString(2, Password);
            insert.setString(3, Email);
            insert.setString(4, Contact);
            insert.setString(5, Name);
            insert.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Record Updated","Update",JOptionPane.INFORMATION_MESSAGE);
            tableUpdate();
            
            eName_TextField.setText("");
            eUsername_TextField.setText("");
            ePassword_TextField.setText("");
            eEmail_TextField.setText("");
            eContact_TextField.setText("");
        }
        else
        {
         JOptionPane.showMessageDialog(null, "Failed to Update profile.","Error",JOptionPane.ERROR_MESSAGE); 
          eName_TextField.setText("");
                    eUsername_TextField.setText("");
                    ePassword_TextField.setText("");
                    eEmail_TextField.setText("");
                    eContact_TextField.setText("");
        }
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (SQLException ex) 
        {
               Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_edit_ButtonActionPerformed

    private void delete_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_delete_ButtonActionPerformed
       
        
        DefaultTableModel dtm = (DefaultTableModel)adminRegistration_Table.getModel();
        int selectedIndex = adminRegistration_Table.getSelectedRow();
            
            String Name = eName_TextField.getText();
            String Username = eUsername_TextField.getText();
            String Password = ePassword_TextField.getText();
            String Email = eEmail_TextField.getText();
            String Contact = eContact_TextField.getText();
        try
        {
        int choice = JOptionPane.showConfirmDialog(this,"Do you sure want to delete", 
                "Delete",JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION )
        {
            
            Class.forName(dbDriver);
            con = DriverManager.getConnection(dbUrl,dbUsername,dbPassword);  
            insert = con.prepareStatement("DELETE FROM userinfo WHERE Name =? ");
            insert.setString(1, Name);
            insert.executeUpdate();
            
            JOptionPane.showMessageDialog(this, "Record Deleted ","Delete",JOptionPane.INFORMATION_MESSAGE);
            tableUpdate();
            
            eName_TextField.setText("");
            eUsername_TextField.setText("");
            ePassword_TextField.setText("");
            eEmail_TextField.setText("");
            eContact_TextField.setText("");
        }
        else
        {
         JOptionPane.showMessageDialog(null, "Failed to delete profile.","Error",JOptionPane.ERROR_MESSAGE);   
          eName_TextField.setText("");
          eUsername_TextField.setText("");
          ePassword_TextField.setText("");
          eEmail_TextField.setText("");
          eContact_TextField.setText("");
        }
        }
       
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (SQLException ex) 
        {
               Logger.getLogger(Registration.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_delete_ButtonActionPerformed

    private void eContact_TextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_eContact_TextFieldKeyTyped
        char c = evt.getKeyChar();
        
        if (Character.isAlphabetic(c))
        {
            eContact_TextField.setEditable(false);
            JOptionPane.showMessageDialog(null, "Input numbers only.", "ERROR",JOptionPane.ERROR_MESSAGE);     
        }
        else
        {
            eContact_TextField.setEditable(true);    
        }
    }//GEN-LAST:event_eContact_TextFieldKeyTyped

    private void logout_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_logout_ButtonActionPerformed
       int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout",
                                        "Logout",JOptionPane.YES_NO_OPTION);
        if (choice ==JOptionPane.YES_OPTION )
        {
            JOptionPane.showMessageDialog(this , "Logout Successfully","Logout",JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
        }
        else
        {
            
        }
    }//GEN-LAST:event_logout_ButtonActionPerformed

    private void clear_ButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_clear_ButtonActionPerformed
        eName_TextField.setText("");
          eUsername_TextField.setText("");
          ePassword_TextField.setText("");
          eEmail_TextField.setText("");
          eContact_TextField.setText("");
    }//GEN-LAST:event_clear_ButtonActionPerformed

    private void showPasswordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_showPasswordMouseClicked
        if (showPassword.isSelected())
        {
            ePassword_TextField.setEchoChar((char)0);
        }
        else 
        {
            ePassword_TextField.setEchoChar('•');
        } 
    }//GEN-LAST:event_showPasswordMouseClicked

    private void eName_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eName_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_eName_TextFieldActionPerformed

    private void eEmail_TextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eEmail_TextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_eEmail_TextFieldActionPerformed


    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new AdminRegistration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add_Button;
    private javax.swing.JLabel adminRegistration_Label;
    private javax.swing.JTable adminRegistration_Table;
    private javax.swing.JButton back_Button;
    private javax.swing.JButton clear_Button;
    private javax.swing.JButton delete_Button;
    private javax.swing.JTextField eContact_TextField;
    private javax.swing.JTextField eEmail_TextField;
    private javax.swing.JTextField eName_TextField;
    private javax.swing.JPasswordField ePassword_TextField;
    private javax.swing.JTextField eUsername_TextField;
    private javax.swing.JButton edit_Button;
    private javax.swing.JLabel email_Label;
    private javax.swing.JButton logout_Button;
    private javax.swing.JPanel main_Panel;
    private javax.swing.JLabel name_Label;
    private javax.swing.JLabel password_Label;
    private javax.swing.JLabel phone_Label;
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JCheckBox showPassword;
    private javax.swing.JLabel username_Label;
    // End of variables declaration//GEN-END:variables
}
